to_remove: {
/*
 * Module shim for rollup.js to work with.
 * Simply re-export Janus from janus.js, the real 'magic' is in the rollup config.
 */
}

@JANUS_CODE@

export default Janus;
